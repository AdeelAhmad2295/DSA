package LinkedList;

public class Dynamic_stack_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
