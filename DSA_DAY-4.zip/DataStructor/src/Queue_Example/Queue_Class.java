package Queue_Example;

public class Queue_Class {
	private int Q[], MaxSize, front,rear;

    public void create_Queue(int size) {
    	front=0;
        rear = -1;//init tos
        Q = new int[size];//create stack
        MaxSize = size;//init MaxSize
    }

    void Enqueue(int e) {
        rear++;
        Q[rear] = e;
        System.out.println("Element " + e + " inserted:");
    }

    boolean is_Full() {
        if (rear == MaxSize - 1)
            return true;
        else
            return false;
    }

    int Dequeue() {
        int temp = Q[front];
        front++;
        return (temp);

        //return(stack[tos--]);
    }

    boolean is_Empty() {
        if (front>rear)//imp
            return true;
        else
            return false;
    }

    
    

    void print_Queue() {//fifo print
        System.out.println("Queue has");
        for (int i = front; i <= rear; i++) {
            System.out.println(Q[i]);
        }

    }
    
}
