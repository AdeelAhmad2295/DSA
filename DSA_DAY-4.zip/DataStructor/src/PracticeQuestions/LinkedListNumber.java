package PracticeQuestions;
import java.util.Scanner;

class Node3 {
    int data;
    Node3 next;

    Node3(int data) {
        this.data = data;
        this.next = null;
    }
}

class DigitLinkedList { 
    Node3 head;

    public void insert(int data) {
        Node3 newNode = new Node3(data);
        if (head == null) {
            head = newNode;
        } else {
            Node3 current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    public void display() {
        Node3 current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}

public class LinkedListNumber {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter a number: ");
        String number = scanner.nextLine();
        
        DigitLinkedList linkedList = new DigitLinkedList();         
        for (char digit : number.toCharArray()) {
            linkedList.insert(Character.getNumericValue(digit));
        }
        
        System.out.println("Linked list representation of the number:");
        linkedList.display();
        
        scanner.close();
    }
}
