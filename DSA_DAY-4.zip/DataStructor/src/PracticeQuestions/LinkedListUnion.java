package PracticeQuestions;

import java.util.Scanner;

class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class SinglyLinkedList {
    Node head;

    public void insertSorted(int data) {
        Node newNode = new Node(data);
        if (head == null || head.data > data) {
            newNode.next = head;
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null && current.next.data < data) {
                current = current.next;
            }
            // Prevent duplicates
            if (current.data != data) {
                newNode.next = current.next;
                current.next = newNode;
            }
        }
    }

    public void display() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public SinglyLinkedList union(SinglyLinkedList other) {
        SinglyLinkedList result = new SinglyLinkedList();
        Node current1 = this.head;
        Node current2 = other.head;

        while (current1 != null && current2 != null) {
            if (current1.data < current2.data) {
                result.insertSorted(current1.data);
                current1 = current1.next;
            } else if (current1.data > current2.data) {
                result.insertSorted(current2.data);
                current2 = current2.next;
            } else {
                result.insertSorted(current1.data);
                current1 = current1.next;
                current2 = current2.next;
            }
        }

        while (current1 != null) {
            result.insertSorted(current1.data);
            current1 = current1.next;
        }

        while (current2 != null) {
            result.insertSorted(current2.data);
            current2 = current2.next;
        }

        return result;
    }
}

public class LinkedListUnion {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        SinglyLinkedList list1 = new SinglyLinkedList();
        SinglyLinkedList list2 = new SinglyLinkedList();

        System.out.println("Enter elements for the first linked list (enter -1 to stop):");
        while (true) {
            int data = scanner.nextInt();
            if (data == -1) break;
            list1.insertSorted(data);
        }

        System.out.println("Enter elements for the second linked list (enter -1 to stop):");
        while (true) {
            int data = scanner.nextInt();
            if (data == -1) break;
            list2.insertSorted(data);
        }

        SinglyLinkedList unionList = list1.union(list2);
        
        System.out.println("Union of the two linked lists:");
        unionList.display();

        scanner.close();
    }
}
