package PracticeQuestions;

import java.util.Scanner;

class Stack {
    private char[] stack;
    private int top;
    private int maxSize;

    public Stack(int size) {
        this.maxSize = size;
        this.stack = new char[maxSize];
        this.top = -1;
    }

    public void push(char ch) {
        if (top < maxSize - 1) {
            stack[++top] = ch;
        } else {
            System.out.println("Stack is full.");
        }
    }

    public char pop() {
        if (top >= 0) {
            return stack[top--];
        } else {
            System.out.println("Stack is empty.");
            return '\0';
        }
    }

    public boolean isEmpty() {
        return top == -1;
    }
}

public class StringReverse {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter a string to reverse: ");
        String input = scanner.nextLine();
        
        Stack stack = new Stack(input.length());
        
       for (char ch : input.toCharArray()) {
            stack.push(ch);
        }

        StringBuilder reversed = new StringBuilder();
        
        while (!stack.isEmpty()) {
            reversed.append(stack.pop());
        }

        System.out.println("Reversed string: " + reversed.toString());
        
        scanner.close();
    }
}
