package linked_list;

public class Dnode {
	int data;
	Dnode left,right;
	Dnode(int data){
		this.data=data;
		left=right=null;
	}
}
