package linked_list;
import java.util.Scanner;

class Dnode1 {
	int data;
	Dnode1 left,right;
	Dnode1(int data){
		this.data=data;
		left=right=null;
	}
}

class Circular_Doubly_Linked_list {
    private Dnode1 root, last;

    // Create an empty list
    void create_list() {
        root = last = null;
    }
    void insert_left(int data) {
        Dnode1 n = new Dnode1(data);
        if (root == null) {
            root = last = n;
            root.right = root;
            root.left = root;
        } else {
            n.right = root;
            n.left = last;
            last.right = n;
            root.left = n;
            root = n; // Update root to the new node
        }
        System.out.println(data + " inserted at left");
    }
    void insert_right(int data) {
        Dnode1 n = new Dnode1(data);
        if (root == null) {
            root = last = n;
            root.right = root;
            root.left = root;
        } else {
            n.left = last;
            n.right = root;
            last.right = n;
            root.left = n;
            last = n;
        }
        System.out.println(data + " inserted at right");
    }
    void delete_left() {
        if (root == null) {
            System.out.println("List is empty");
        } else if (root == last) {
            System.out.println(root.data + " deleted");
            root = last = null; // Only one element
        } else {
            Dnode1 temp = root;
            root = root.right;
            root.left = last;
            last.right = root;
            System.out.println(temp.data + " deleted");
        }
    }
    void delete_right() {
        if (root == null) {
            System.out.println("List is empty");
        } else if (root == last) {
            System.out.println(root.data + " deleted");
            root = last = null; // Only one element
        } else {
            Dnode1 temp = last;
            last = last.left;
            last.right = root;
            root.left = last;
            System.out.println(temp.data + " deleted");
        }
    }

    // Print the list from left to right
    void print_all() {
        if (root == null) {
            System.out.println("List is empty");
        } else {
            Dnode1 temp = root;
            do {
                System.out.print("<-|" + temp.data + "|->");
                temp = temp.right;
            } while (temp != root);
            System.out.println();
        }
    }
    void print_reverse() {
        if (root == null) {
            System.out.println("List is empty");
        } else {
            Dnode1 temp = last;
            do {
                System.out.print("<-|" + temp.data + "|->");
                temp = temp.left;
            } while (temp != last);
            System.out.println();
        }
    }
}

public class Circular_Doubly_Linked_list_Main {
	    public static void main(String[] args) {
	        Circular_Doubly_Linked_list obj = new Circular_Doubly_Linked_list();
	        Scanner in = new Scanner(System.in);
	        int ch, e;
	        obj.create_list();
	        do {
	        	System.out.println("*******Circular Doubly Link List*******");
	            System.out.println("1. Insert Left");
	            System.out.println("2. Insert Right");
	            System.out.println("3. Delete Left");
	            System.out.println("4. Delete Right");
	            System.out.println("5. Print All");
	            System.out.println("6. Print Reverse");
	            System.out.println("0. Exit");
	            System.out.print("Enter your choice: ");
	            ch = in.nextInt();
	            switch (ch) {
	                case 1:
	                    System.out.println("Enter element:");
	                    e = in.nextInt();
	                    obj.insert_left(e);
	                    break;

	                case 2: // New case for insert left
	                    System.out.println("Enter element:");
	                    e = in.nextInt();
	                    obj.insert_right(e);
	                    break;

	                case 3:
	                    obj.delete_left();
	                    break;

	                case 4:
	                    obj.delete_right();
	                    break;

	                case 5:
	                    obj.print_all();
	                    break;

	                case 6:
	                    obj.print_reverse();
	                    break;

	                case 0:
	                    System.out.println("Exiting....");
	                    break;

	                default:
	                    System.out.println("Wrong option selected");
	                    break;
	            }
	        } while (ch != 0);

	        in.close(); 
	    }
	}
