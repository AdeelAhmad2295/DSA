package graph;
import java.util.Scanner;

class Employee {
    int id;
    String name;
    double salary;
    String email;
    Employee next;

    Employee(int id, String name, double salary, String email) {
        this.id = id;
        this.name = name;
        this.salary = salary;
        this.email = email;
        this.next = null;
    }
}

class EmployeeLinkedList {
    private Employee head;

    // Add a new employee to the linked list
    public String addEmployee(int id, String name, double salary, String email) {
        if (findEmployee(id) != null) {
            return "Error: Employee ID already exists.";
        }
        Employee newEmployee = new Employee(id, name, salary, email);
        if (head == null) {
            head = newEmployee;
        } else {
            Employee current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newEmployee;
        }
        return "Employee registered successfully.";
    }

    // Find an employee by ID
    public String findEmployee(int id) {
        Employee current = head;
        while (current != null) {
            if (current.id == id) {
                return "Employee Found: ID: " + current.id + ", Name: " + current.name + 
                       ", Salary: " + current.salary + ", Email: " + current.email;
            }
            current = current.next;
        }
        return null; // Return null if employee not found
    }

    // Display all employees
    public String displayAllEmployees() {
        if (head == null) {
            return "No employees found.";
        }
        StringBuilder result = new StringBuilder();
        Employee current = head;
        while (current != null) {
            result.append("ID: ").append(current.id)
                  .append(", Name: ").append(current.name)
                  .append(", Salary: ").append(current.salary)
                  .append(", Email: ").append(current.email)
                  .append("\n");
            current = current.next;
        }
        return result.toString();
    }
}

// Main class to interact with the EmployeeLinkedList
public class EmployeeManagementSystem {
    public static void main(String[] args) {
        EmployeeLinkedList employeeList = new EmployeeLinkedList();
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\nEmployee Management System");
            System.out.println("1. Add Employee");
            System.out.println("2. Find Employee by ID");
            System.out.println("3. Display All Employees");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter Employee ID: ");
                    int id = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter Employee Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Employee Salary: ");
                    double salary = scanner.nextDouble();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter Employee Email: ");
                    String email = scanner.nextLine();
                    System.out.println(employeeList.addEmployee(id, name, salary, email));
                    break;

                case 2:
                    System.out.print("Enter Employee ID to search: ");
                    int searchId = scanner.nextInt();
                    String foundEmployee = employeeList.findEmployee(searchId);
                    if (foundEmployee != null) {
                        System.out.println(foundEmployee);
                    } else {
                        System.out.println("Error: Employee not found.");
                    }
                    break;

                case 3:
                    System.out.println("All Employees:");
                    System.out.println(employeeList.displayAllEmployees());
                    break;

                case 4:
                    System.out.println("Exiting the system. Goodbye!");
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 4);

        scanner.close();
    }
}


