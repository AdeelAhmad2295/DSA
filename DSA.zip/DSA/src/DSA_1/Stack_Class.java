package DSA_1;
public class Stack_Class {
    private int stack[];
    private int MaxSize;
    private int tos; // top of stack
    // Create Stack
    public void create_Stack(int size) {
        tos = -1; // initialize top of stack
        stack = new int[size]; // create stack with given size
        MaxSize = size; // set max size
    }
    // Push element onto the stack
    public void push(int e) {
        if (is_Full()) {
            System.out.println("Stack is full. Cannot push element " + e);
        } else {
            tos++;
            stack[tos] = e;
            System.out.println("Element " + e + " pushed.");
        }
    }
    // Check if stack is full
    public boolean is_Full() {
        return tos == MaxSize - 1;
    }
    // Pop element from the stack
    public int pop() {
        if (is_Empty()) {
            System.out.println("Stack is empty. Cannot pop element.");
            return -1; // return a sentinel value indicating an error
        } else {
            int temp = stack[tos];
            tos--;
            return temp;
        }
    }
    // Check if stack is empty
    public boolean is_Empty() {
        return tos == -1;
    }
    // Peek at the top element of the stack
    public int peek() {
        if (is_Empty()) {
            System.out.println("Stack is empty. Cannot peek.");
            return -1; // return a sentinel value indicating an error
        } else {
            return stack[tos];
        }
    }
    // Print the stack elements (LIFO order)
    public void print_Stack() {
        if (is_Empty()) {
            System.out.println("Stack is empty.");
        } else {
            System.out.println("Stack has:");
            for (int i = tos; i >= 0; i--) {
                System.out.println(stack[i]);
            }
        }
    }
}
