package DSA_1;

public class Wellness_Stack {

}
