package DSA_1;

import java.util.Scanner;

public class Dec_Binary_Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Dec_Binary obj = new Dec_Binary(); // object created
        
        System.out.println("Enter a decimal number:"); // prompt user for input
        int decimal = in.nextInt(); // read the decimal number from user

        obj.create_Stack(64); // create stack with sufficient size for binary representation

        // Convert decimal to binary by pushing remainders onto the stack
        int temp = decimal;
        while (temp > 0) {
            int remainder = temp % 2; // get remainder
            obj.push(remainder); // push remainder onto the stack
            temp = temp / 2; // divide the number by 2
        }

        // Pop each element from the stack to get the binary representation
        System.out.print("Binary of " + decimal + " is: ");
        while (!obj.is_Empty()) { // while stack is not empty
            System.out.print(obj.pop());
        }

        System.out.println(); // move to next line after printing binary
        in.close(); // close the scanner to avoid resource leaks
    }
}
