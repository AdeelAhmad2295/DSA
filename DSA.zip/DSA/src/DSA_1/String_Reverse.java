package DSA_1;

import java.util.Scanner;

public class String_Reverse {
	public static void main(String args[]) {
		Scanner in = new Scanner(System.in);
		Stack_Character obj = new Stack_Character();
		System.out.println("Enter Word:");//object created System.out.println("Enter word");
		String word=in.next();
		obj.create_Stack(word.length());//read word from user obj.create_Stack(word.length());
		for(int i=0;i<word.length();i++) {
			obj.push(word.charAt(i));//character by charater copy element to stack till all characters are over obj.push(word.charAt(i));

		}
		 String r_word = "";
	        while (!obj.is_Empty()) { // while stack is not empty
	            r_word += obj.pop();
	        }

	        System.out.println("Reverse is: " + r_word); // print the reversed string

	        in.close(); // close the scanner to avoid resource leaks
	    }
	}