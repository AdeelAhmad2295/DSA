package linked_list;

public class Dynamic_Stack_Class {
	Node tos;
    void create_Stack() {
        tos = null;//preparing with empty root
    }

    void push(int data) {
        Node n = new Node(data);
        if (tos == null) {
        	tos  = n;//n becomes 1st so root
        } else {
            n.next = tos ;//1
            tos  = n;//2
        }
        System.out.println(tos.data + " inserted");

    }

    void pop() {
        if (tos == null) {
            System.out.println("Empty Stack");
        } else {
            Node t = tos;   // Save current top of stack
            tos = tos.next; // Update top of stack to the next node
            System.out.println(t.data + " popped");
        }
    }
    	void peek() {
    		if (tos == null)
    		{
    				System.out.println("Empty Stack");
    		}
    	else
    	{
    		System.out.println(tos.data + " @ peek");
    	}
    }
    	void print_stack() 
    	{
    		if (tos == null) {
    			System.out.println("Stack Empty");
    		}
    	else {
    		Node t = tos;
	    	while (t != null) {
	    	System.out.println(t.data );
	    	System.out.println("-----------");
	    	t = t.next;
    	}
    }
}


    	}