package linked_list;

import java.util.Scanner;

public class Dynamic_Stack_Class_Main
{
    public static void main(String args[]) {
        Dynamic_Stack_Class obj = new Dynamic_Stack_Class();
        Scanner in = new Scanner(System.in);
        int ch, e;
        obj.create_Stack();//creating LinkedList
        do {
        	 System.out.println("\nStack Menu");
             System.out.println("-----------");
             System.out.println("1. Push");
             System.out.println("2. Pop");
             System.out.println("3. Peek");
             System.out.println("4. Print all elements");
             System.out.println("0. Exit");
             System.out.println("-----------");
             System.out.println("Choice:");
             ch = in.nextInt();

             switch (ch) {
                 case 1:
                         System.out.println("Enter a number:");
                         e = in.nextInt();
                         obj.push(e);                    
                         break;

                 case 2:
                	 obj.pop();
                     break;

                 case 3:
                	 obj.peek();
                	 break;

                 case 4:
                     obj.print_stack();
                     break;

                 case 0:
                     System.out.println("Thanks for using the code, coded by amartechnavigator");
                     break;

                 default:
                     System.out.println("Wrong option selected");
                     break;
             }
         } while (ch != 0);

         in.close(); // Closing the scanner to prevent resource leaks
     }
 }
