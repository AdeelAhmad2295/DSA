package linked_list;

import java.util.Scanner;

public class Dynamic_Queue_Main {
	    public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);
	        Dynamic_Queue queue = new Dynamic_Queue();
	        queue.create_Queue(); // Initialize the queue

	        int choice, data;

	        // Menu loop
	        do {
	            System.out.println("\nMenu:");
	            System.out.println("1. Enqueue");
	            System.out.println("2. Dequeue");
	            System.out.println("3. Display Queue");
	            System.out.println("4. Exit");
	            System.out.print("Enter your choice: ");
	            choice = sc.nextInt();

	            switch (choice) {
	                case 1:
	                    System.out.print("Enter data to insert: ");
	                    data = sc.nextInt();
	                    queue.Enqueue(data);
	                    break;

	                case 2:
	                    queue.Dequeue();
	                    break;

	                case 3:
	                    queue.print_queue();
	                    break;

	                case 4:
	                    System.out.println("Exiting...");
	                    break;

	                default:
	                    System.out.println("Invalid choice! Please try again.");
	                    break;
	            }
	        } while (choice != 4);

	        sc.close();
	    }
}

