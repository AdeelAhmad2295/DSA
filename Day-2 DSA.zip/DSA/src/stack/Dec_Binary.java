package stack;

class Dec_Binary {
    private int[] stack;
    private int MaxSize;
    private int tos; // top of stack

    // Create Stack
    public void create_Stack(int size) {
        tos = -1; // initialize top of stack
        stack = new int[size]; // create stack for integers
        MaxSize = size; // set max size
    }

    // Push integer onto the stack
    public void push(int num) {
        if (tos < MaxSize - 1) {
            tos++;
            stack[tos] = num;
        } else {
            System.out.println("Stack is full. Cannot push element " + num);
        }
    }

    // Pop integer from the stack
    public int pop() {
        if (tos == -1) {
            System.out.println("Stack is empty. Cannot pop element.");
            return -1; // return a sentinel value for error
        } else {
            int temp = stack[tos];
            tos--;
            return temp;
        }
    }

    // Check if stack is empty
    public boolean is_Empty() {
        return tos == -1;
    }
}