package stack;

class Stack_Character {
    private char[] stack;
    private int MaxSize;
    private int tos; // top of stack

    // Create Stack
    public void create_Stack(int size) {
        tos = -1; // initialize top of stack
        stack = new char[size]; // create stack for characters
        MaxSize = size; // set max size
    }

    // Push character onto the stack
    public void push(char c) {
        if (tos < MaxSize - 1) {
            tos++;
            stack[tos] = c;
        } else {
            System.out.println("Stack is full. Cannot push character " + c);
        }
    }

    // Pop character from the stack
    public char pop() {
        if (tos == -1) {
            System.out.println("Stack is empty. Cannot pop character.");
            return '\0'; // return null character if empty
        } else {
            char temp = stack[tos];
            tos--;
            return temp;
        }
    }

    // Check if stack is empty
    public boolean is_Empty() {
        return tos == -1;
    }
}