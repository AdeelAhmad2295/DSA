package queue;

public class Queue_Class 
{
	  	private int Queue[];
	    private int MaxSize;
	    private int front; // top of stack
	    private int rear;
	    // Create Stack
	    public void create_Queue(int size) {
	        MaxSize = size; // initialize top of stack
	        front =0; // create stack with given size
	        rear=-1; // set max size
	        Queue=new int [size];
	    }
	    // Push element onto the stack
	    void Enqueue(int e) {
	        rear++;
	        Queue[rear]=e;
	        System.out.println("Element "+e+" Inserted Queue.");
	    }
	    public boolean is_Full() {
	        if(rear==MaxSize-1)
	        	return true;
	        else
	        	return false;
	    }
	    int Dequeue() {
	    	int temp=Queue[front];
	    	front++;
	    	return (temp);
	    }
	    // Check if stack is empty
	    public boolean is_Empty() {
	        if(front>rear)
	        	return true;
	        else
	        	return false;
	    }

	    // Print the stack elements (LIFO order)
	    public void print_Queue() 
	    {
	            System.out.println("Queue has");
	            for (int i = front; i <=rear; i++) 
	            {
	            
	                System.out.print(Queue[i]+",");
	            }
	     }
} 


