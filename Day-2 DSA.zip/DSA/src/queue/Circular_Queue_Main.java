package queue;

import java.util.Scanner;

public class Circular_Queue_Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Circular_Queue obj = new Circular_Queue(); // Circular queue object created

        System.out.println("Enter size of Queue:");
        int size = in.nextInt();
        obj.create_Queue(size);

        int ch, e;
        do {
            System.out.println("\nQueue Menu");
            System.out.println("-----------");
            System.out.println("1. Enqueue");
            System.out.println("2. Dequeue");
            System.out.println("3. Print all elements");
            System.out.println("0. Exit");
            System.out.println("-----------");
            System.out.println("Choice:");
            ch = in.nextInt();

            switch (ch) {
                case 1:
                    if (!obj.is_Full()) { // Queue not full
                        System.out.println("Enter a number:");
                        e = in.nextInt();
                        obj.Enqueue(e);
                    } else {
                        System.out.println("Queue Full");
                    }
                    break;

                case 2:
                    if (!obj.is_Empty()) { // Queue not empty
                        System.out.println("Element Dequeued is " + obj.Dequeue());
                    } else {
                        System.out.println("Queue Empty");
                    }
                    break;

                case 3:
                    if (!obj.is_Empty()) { // Queue not empty
                        System.out.println("Elements in Queue are:");
                        obj.print_Queue();
                    } else {
                        System.out.println("Queue Empty");
                    }
                    break;

                case 0:
                    System.out.println("Thanks for using the code, coded by adeelahmad");
                    break;

                default:
                    System.out.println("Wrong option selected");
                    break;
            }
        } while (ch != 0);

        in.close(); // Closing the scanner to prevent resource leaks
    }
}
