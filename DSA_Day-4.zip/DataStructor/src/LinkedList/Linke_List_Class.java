package LinkedList;

public class Linke_List_Class {
// create_list()
	//inser_left(e)
	//inser_right(e)
	//inser_right(e)
	Node root;
	void create_list() {
		root=null;
	}
	void inser_left(int data)
	{
		Node n=new Node(data);
				if(root==null)
				{
					root=n;
				}
				else {
					n.next=root;
					root=n;
				}
		System.out.println(root.data+"inserted");
	}
	void delete_left(int data)
	{
		Node n=new Node(data);
				if(root==null)
				{
					System.out.println("empty list");
				}
				else {
					Node t;
					t=root;
					root=root.next;
					System.out.println(t.data+"deleted");
				}
		
	}
	void inser_right(int data)
	{
		Node n=new Node(data);
				if(root==null)
				{
					root=n;
				}
				else {
					Node t;
					t=root;
					while(t.next!=null)
					{
						t=t.next;
					t.next=n;
					}
				}
		System.out.println(root.data+"inserted");
	}
	void delete_right()
	{
	if(root==null)
	System.out.println("Empty List");
	else
	{
	Node t,t2;
	t=t2=root;//1 while(t.next!=null)
	{
	t2=t;
	t=t.next;
	}
	if(t==root)//single node root=null;//reset root as only node left else
	t2.next = null;
	System.out.println(t.data + " deleted");
	}
	}
	public void search_list(int e) {
	
		
	}
	public void insert_after(int key, int e) {
		
		
	}
	public void print_list() {
		// TODO Auto-generated method stub
		
	}
	
}