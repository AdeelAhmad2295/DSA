package linked_list;
class CircularDoublyLinkedList {
    private Node head;

    public CircularDoublyLinkedList() {
        head = null;
    }

    // Insert a new node at the end (rightmost) of the list
    public void insertAtEnd(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
            head.next = head;
            head.next = head;
        } else {
            Node tail = head.next;
            tail.next = newNode;
            newNode.next = tail;
            newNode.next = head;
            head.next = newNode;
        }
    }

    // Remove the leftmost node from the list
    public void removeLeftmost() {
        if (head == null) {
            System.out.println("List is empty. Nothing to remove.");
            return;
        }
        if (head.next == head) { // Only one node
            head = null;
        } else {
            Node tail = head.next;
            tail.next = head.next;
            head.next.next = tail;
            head = head.next;
        }
    }

    // Remove the rightmost node from the list
    public void removeRightmost() {
        if (head == null) {
            System.out.println("List is empty. Nothing to remove.");
            return;
        }
        if (head.next == head) { // Only one node
            head = null;
        } else {
            Node tail = head.next;
            tail.next.next = head;
            head.next = tail.next;
        }
    }

    // Traverse the list from the head to the tail and print the value of each node
    public void traverseForward() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }
        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }

    // Traverse the list from the tail to the head and print the value of each node
    public void traverseBackward() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }
        Node current = head.next;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head.next);
        System.out.println();
    }

    public static void main(String[] args) {
        CircularDoublyLinkedList list = new CircularDoublyLinkedList();

        // Testing the operations
        list.insertAtEnd(10);
        list.insertAtEnd(20);
        list.insertAtEnd(30);
        
        System.out.print("Traverse Forward: ");
        list.traverseForward(); // Output: 10 20 30

        System.out.print("Traverse Backward: ");
        list.traverseBackward(); // Output: 30 20 10

        list.removeLeftmost();
        System.out.print("After removing leftmost: ");
        list.traverseForward(); // Output: 20 30

        list.removeRightmost();
        System.out.print("After removing rightmost: ");
        list.traverseForward(); // Output: 20
    }
}
